﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ChessGame
{
    public partial class MainWindow : Window
    {
        private string s = "";
        private Brush clr;
        DataRow row;
        DataTable dt = new DataTable();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void A8_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = A8.Content.ToString(); }
                catch (Exception) { }
                A8.Content = "";
            }
            else
            {
                A8.Content = s;
                s = "";
            }
        }

        private void B8_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = B8.Content.ToString(); }
                catch (Exception) { }
                B8.Content = "";
            }
            else
            {
                B8.Content = s;
                s = "";
            }
        }

        private void C8_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = C8.Content.ToString(); }
                catch (Exception) { }
                C8.Content = "";
            }
            else
            {
                C8.Content = s;
                s = "";
            }
        }

        private void D8_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = D8.Content.ToString(); }
                catch (Exception) { }
                D8.Content = "";
            }
            else
            {
                D8.Content = s;
                s = "";
            }
        }

        private void E8_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = E8.Content.ToString(); }
                catch (Exception) { }
                E8.Content = "";
            }
            else
            {
                E8.Content = s;
                s = "";
            }
        }

        private void F8_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = F8.Content.ToString(); }
                catch (Exception) { }
                F8.Content = "";
            }
            else
            {
                F8.Content = s;
                s = "";
            }
        }

        private void G8_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = G8.Content.ToString(); }
                catch (Exception) { }
                G8.Content = "";
            }
            else
            {
                G8.Content = s;
                s = "";
            }
        }

        private void H8_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = H8.Content.ToString(); }
                catch (Exception) { }
                H8.Content = "";
            }
            else
            {
                H8.Content = s;
                s = "";
            }
        }

        private void A7_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = A7.Content.ToString(); }
                catch (Exception) { }
                A7.Content = "";
            }
            else
            {
                A7.Content = s;
                s = "";
            }
        }

        private void B7_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = B7.Content.ToString(); }
                catch (Exception) { }
                B7.Content = "";
            }
            else
            {
                B7.Content = s;
                s = "";
            }
        }

        private void C7_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = C7.Content.ToString(); }
                catch (Exception) { }
                C7.Content = "";
            }
            else
            {
                C7.Content = s;
                s = "";
            }
        }

        private void D7_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = D7.Content.ToString(); }
                catch (Exception) { }
                D7.Content = "";
            }
            else
            {
                D7.Content = s;
                s = "";
            }
        }

        private void E7_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = E7.Content.ToString(); }
                catch (Exception) { }
                E7.Content = "";
            }
            else
            {
                E7.Content = s;
                s = "";
            }
        }

        private void F7_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = F7.Content.ToString(); }
                catch (Exception) { }
                F7.Content = "";
            }
            else
            {
                F7.Content = s;
                s = "";
            }
        }

        private void G7_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = G7.Content.ToString(); }
                catch (Exception) { }
                G7.Content = "";
            }
            else
            {
                G7.Content = s;
                s = "";
            }
        }

        private void H7_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = H7.Content.ToString(); }
                catch (Exception) { }
                H7.Content = "";
            }
            else
            {
                H7.Content = s;
                s = "";
            }
        }

        private void A6_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = A6.Content.ToString(); }
                catch (Exception) { }
                A6.Content = "";
            }
            else
            {
                A6.Content = s;
                s = "";
            }
        }

        private void B6_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = B6.Content.ToString(); }
                catch (Exception) { }
                B6.Content = "";
            }
            else
            {
                B6.Content = s;
                s = "";
            }
        }

        private void C6_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = C6.Content.ToString(); }
                catch (Exception) { }
                C6.Content = "";
            }
            else
            {
                C6.Content = s;
                s = "";
            }
        }

        private void D6_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = D6.Content.ToString(); }
                catch (Exception) { }
                D6.Content = "";
            }
            else
            {
                D6.Content = s;
                s = "";
            }
        }

        private void E6_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = E6.Content.ToString(); }
                catch (Exception) { }
                E6.Content = "";
            }
            else
            {
                E6.Content = s;
                s = "";
            }
        }

        private void F6_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = F6.Content.ToString(); }
                catch (Exception) { }
                F6.Content = "";
            }
            else
            {
                F6.Content = s;
                s = "";
            }
        }

        private void G6_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = G6.Content.ToString(); }
                catch (Exception) { }
                G6.Content = "";
            }
            else
            {
                G6.Content = s;
                s = "";
            }
        }

        private void H6_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = H6.Content.ToString(); }
                catch (Exception) { }
                H6.Content = "";
            }
            else
            {
                H6.Content = s;
                s = "";
            }
        }

        private void A5_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = A5.Content.ToString(); }
                catch (Exception) { }
                A5.Content = "";
            }
            else
            {
                A5.Content = s;
                s = "";
            }
        }

        private void B5_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = B5.Content.ToString(); }
                catch (Exception) { }
                B5.Content = "";
            }
            else
            {
                B5.Content = s;
                s = "";
            }
        }

        private void C5_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = C5.Content.ToString(); }
                catch (Exception) { }
                C5.Content = "";
            }
            else
            {
                C5.Content = s;
                s = "";
            }
        }

        private void D5_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = D5.Content.ToString(); }
                catch (Exception) { }
                D5.Content = "";
            }
            else
            {
                D5.Content = s;
                s = "";
            }
        }

        private void E5_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = E5.Content.ToString(); }
                catch (Exception) { }
                E5.Content = "";
            }
            else
            {
                E5.Content = s;
                s = "";
            }
        }

        private void F5_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = F5.Content.ToString(); }
                catch (Exception) { }
                F5.Content = "";
            }
            else
            {
                F5.Content = s;
                s = "";
            }
        }

        private void G5_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = G5.Content.ToString(); }
                catch (Exception) { }
                G5.Content = "";
            }
            else
            {
                G5.Content = s;
                s = "";
            }
        }

        private void H5_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = H5.Content.ToString(); }
                catch (Exception) { }
                H5.Content = "";
            }
            else
            {
                H5.Content = s;
                s = "";
            }
        }

        private void A4_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try
                {
                    s = A4.Content.ToString();
                }
                catch (Exception)
                {
                }
                A4.Content = "";
            }
            else
            {
                A4.Content = s;
                s = "";
            }
        }

        private void B4_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = B4.Content.ToString(); } catch (Exception) { }
                B4.Content = "";
            }
            else
            {
                B4.Content = s;
                s = "";
            }
        }

        private void C4_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = C4.Content.ToString(); }
                catch (Exception) { }
                C4.Content = "";
            }
            else
            {
                C4.Content = s;
                s = "";
            }
        }

        private void D4_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = D4.Content.ToString(); }
                catch (Exception) { }
                D4.Content = "";
            }
            else
            {
                D4.Content = s;
                s = "";
            }
        }

        private void F4_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = F4.Content.ToString(); }
                catch (Exception) { }
                F4.Content = "";
            }
            else
            {
                F4.Content = s;
                s = "";
            }
        }

        private void E4_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = E4.Content.ToString(); }
                catch (Exception) { }
                E4.Content = "";
            }
            else
            {
                E4.Content = s;
                s = "";
            }
        }

        private void G4_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = G4.Content.ToString(); }
                catch (Exception) { }
                G4.Content = "";
            }
            else
            {
                G4.Content = s;
                s = "";
            }
        }

        private void H4_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try { s = H4.Content.ToString(); }
                catch (Exception) { }
                H4.Content = "";
            }
            else
            {
                H4.Content = s;
                s = "";
            }
        }

        private void A3_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try
                {
                    s = A3.Content.ToString();
                }
                catch (Exception)
                {
                }
                A3.Content = "";
            }
            else
            {
                A3.Content = s;
                s = "";
            }
        }

        private void B3_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try
                {
                    s = B3.Content.ToString();
                }
                catch (Exception)
                {
                }
                B3.Content = "";
            }
            else
            {
                B3.Content = s;
                s = "";
            }
        }

        private void C3_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try
                {
                    s = C3.Content.ToString();
                }
                catch (Exception)
                {
                }
                C3.Content = "";
            }
            else
            {
                C3.Content = s;
                s = "";
            }
        }

        private void D3_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try
                {
                    s = D3.Content.ToString();
                }
                catch (Exception)
                {
                }
                D3.Content = "";
            }
            else
            {
                D3.Content = s;
                s = "";
            }
        }

        private void E3_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try
                {
                    s = E3.Content.ToString();
                }
                catch (Exception)
                {
                }
                E3.Content = "";
            }
            else
            {
                E3.Content = s;
                s = "";
            }
        }

        private void F3_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try
                {
                    s = F3.Content.ToString();
                }
                catch (Exception)
                {
                }
                F3.Content = "";
            }
            else
            {
                F3.Content = s;
                s = "";
            }
        }

        private void G3_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try
                {
                    s = G3.Content.ToString();
                }
                catch (Exception)
                {
                }
                G3.Content = "";
            }
            else
            {
                G3.Content = s;
                s = "";
            }
        }

        private void H3_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try
                {
                    s = H3.Content.ToString();
                }
                catch (Exception)
                {
                }
                H3.Content = "";
            }
            else
            {
                H3.Content = s;
                s = "";
            }
        }

        private void A2_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try
                {
                    s = A2.Content.ToString();
                }
                catch (Exception)
                {
                }
                A2.Content = "";
            }
            else
            {
                A2.Content = s;
                s = "";
            }
        }

        private void B2_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try
                {
                    s = B2.Content.ToString();
                }
                catch (Exception)
                {
                }

                B2.Content = "";
            }
            else
            {
                B2.Content = s;
                s = "";
            }
        }

        private void C2_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try
                {
                    s = C2.Content.ToString();
                }
                catch (Exception)
                {
                }

                C2.Content = "";
            }
            else
            {
                C2.Content = s;
                s = "";
            }
        }

        private void D2_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try
                {
                    s = D2.Content.ToString();
                }
                catch (Exception)
                {
                }

                D2.Content = "";
            }
            else
            {
                D2.Content = s;
                s = "";
            }
        }

        private void E2_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try
                {
                    s = E2.Content.ToString();
                }
                catch (Exception)
                {
                }
                E2.Content = "";
            }
            else
            {
                E2.Content = s;
                s = "";
            }
        }

        private void F2_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try
                {
                    s = F2.Content.ToString();
                }
                catch (Exception)
                {
                }
                F2.Content = "";
            }
            else
            {
                F2.Content = s;
                s = "";
            }
        }

        private void G2_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try
                {
                    s = G2.Content.ToString();
                }
                catch (Exception)
                {
                }
                G2.Content = "";
            }
            else
            {
                G2.Content = s;
                s = "";
            }
        }

        private void H2_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try
                {
                    s = H2.Content.ToString();
                }
                catch (Exception)
                {
                }
                H2.Content = "";
            }
            else
            {
                H2.Content = s;
                s = "";
            }
        }

        private void A1_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try
                {
                    s = A1.Content.ToString();
                }
                catch (Exception)
                {
                }

                A1.Content = "";
            }
            else
            {
                A1.Content = s;
                s = "";
            }
        }

        private void B1_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try
                {
                    s = B1.Content.ToString();
                }
                catch (Exception)
                {
                }
                B1.Content = "";
            }
            else
            {
                B1.Content = s;
                s = "";
            }
        }

        private void C1_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try
                {
                    s = C1.Content.ToString();
                }
                catch (Exception)
                {
                }
                C1.Content = "";
            }

            else
            {
                C1.Content = s;
                s = "";
            }
        }

        private void D1_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try
                {
                    s = D1.Content.ToString();
                }
                catch (Exception)
                {
                }

                D1.Content = "";
            }
            else
            {
                D1.Content = s;
                s = "";
            }
        }

        private void E1_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try
                {
                    s = E1.Content.ToString();
                }
                catch (Exception)
                {
                }

                E1.Content = "";
            }
            else
            {
                E1.Content = s;
                s = "";
            }
        }

        private void F1_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try
                {
                    s = F1.Content.ToString();
                }
                catch (Exception)
                {


                }

                F1.Content = "";
            }
            else
            {
                F1.Content = s;
                s = "";
            }
        }

        private void G1_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try
                {
                    s = G1.Content.ToString();
                }
                catch (Exception)
                {
                }
                G1.Content = "";
            }
            else
            {
                G1.Content = s;
                s = "";
            }
        }

        private void H1_Click(object sender, RoutedEventArgs e)
        {
            if (s == "")
            {
                try
                {
                    s = H1.Content.ToString();
                }
                catch (Exception)
                {
                }
                H1.Content = "";
            }
            else
            {
                H1.Content = s;
                s = "";
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            dt = new DataTable();
            for (int i = 1; i <= 8; i++)
            {
                dt.Columns.Add(i.ToString(), typeof(string));
            }

            dt.Rows.Add(A8.Content, B8.Content, C8.Content, D8.Content, E8.Content, F8.Content, G8.Content, H8.Content);
            dt.Rows.Add(A7.Content, B7.Content, C7.Content, D7.Content, E7.Content, F7.Content, G7.Content, H7.Content);
            dt.Rows.Add(A6.Content, B6.Content, C6.Content, D6.Content, E6.Content, F6.Content, G6.Content, H6.Content);
            dt.Rows.Add(A5.Content, B5.Content, C5.Content, D5.Content, E5.Content, F5.Content, G5.Content, H5.Content);
            dt.Rows.Add(A4.Content, B4.Content, C4.Content, D4.Content, E4.Content, F4.Content, G4.Content, H4.Content);
            dt.Rows.Add(A3.Content, B3.Content, C3.Content, D3.Content, E3.Content, F3.Content, G3.Content, H3.Content);
            dt.Rows.Add(A2.Content, B2.Content, C2.Content, D2.Content, E2.Content, F2.Content, G2.Content, H2.Content);
            dt.Rows.Add(A1.Content, B1.Content, C1.Content, D1.Content, E1.Content, F1.Content, G1.Content, H1.Content);


            var dataSet = new DataSet();
            dataSet.Tables.Add(dt);
            dataSet.WriteXml("chess.xml");

            MessageBox.Show("Saved Successfully");
            Application.Current.MainWindow.Close();

        }

        private void btnLoad_Click(object sender, RoutedEventArgs e)
        {
            var dataSet = new DataSet();
            dataSet.ReadXml("chess.xml");
            dt = dataSet.Tables[0];

            // fill A column
            A8.Content = dt.Rows[0][0].ToString();
            A7.Content = dt.Rows[1][0].ToString();
            A6.Content = dt.Rows[2][0].ToString();
            A5.Content = dt.Rows[3][0].ToString();
            A4.Content = dt.Rows[4][0].ToString();
            A3.Content = dt.Rows[5][0].ToString();
            A2.Content = dt.Rows[6][0].ToString();
            A1.Content = dt.Rows[7][0].ToString();

            // fill b column
            B8.Content = dt.Rows[0][1].ToString();
            B7.Content = dt.Rows[1][1].ToString();
            B6.Content = dt.Rows[2][1].ToString();
            B5.Content = dt.Rows[3][1].ToString();
            B4.Content = dt.Rows[4][1].ToString();
            B3.Content = dt.Rows[5][1].ToString();
            B2.Content = dt.Rows[6][1].ToString();
            B1.Content = dt.Rows[7][1].ToString();

            // FILL C COLUMN
            C8.Content = dt.Rows[0][2].ToString();
            C7.Content = dt.Rows[1][2].ToString();
            C6.Content = dt.Rows[2][2].ToString();
            C5.Content = dt.Rows[3][2].ToString();
            C4.Content = dt.Rows[4][2].ToString();
            C3.Content = dt.Rows[5][2].ToString();
            C2.Content = dt.Rows[6][2].ToString();
            C1.Content = dt.Rows[7][2].ToString();

            // FILL D COLUMN
            D8.Content = dt.Rows[0][3].ToString();
            D7.Content = dt.Rows[1][3].ToString();
            D6.Content = dt.Rows[2][3].ToString();
            D5.Content = dt.Rows[3][3].ToString();
            D4.Content = dt.Rows[4][3].ToString();
            D3.Content = dt.Rows[5][3].ToString();
            D2.Content = dt.Rows[6][3].ToString();
            D1.Content = dt.Rows[7][3].ToString();

            // FILL E COLUMN
            E8.Content = dt.Rows[0][4].ToString();
            E7.Content = dt.Rows[1][4].ToString();
            E6.Content = dt.Rows[2][4].ToString();
            E5.Content = dt.Rows[3][4].ToString();
            E4.Content = dt.Rows[4][4].ToString();
            E3.Content = dt.Rows[5][4].ToString();
            E2.Content = dt.Rows[6][4].ToString();
            E1.Content = dt.Rows[7][4].ToString();

            // FILL F COLUMN
            F8.Content = dt.Rows[0][5].ToString();
            F7.Content = dt.Rows[1][5].ToString();
            F6.Content = dt.Rows[2][5].ToString();
            F5.Content = dt.Rows[3][5].ToString();
            F4.Content = dt.Rows[4][5].ToString();
            F3.Content = dt.Rows[5][5].ToString();
            F2.Content = dt.Rows[6][5].ToString();
            F1.Content = dt.Rows[7][5].ToString();

            // FILL G COLUMN
            G8.Content = dt.Rows[0][6].ToString();
            G7.Content = dt.Rows[1][6].ToString();
            G6.Content = dt.Rows[2][6].ToString();
            G5.Content = dt.Rows[3][6].ToString();
            G4.Content = dt.Rows[4][6].ToString();
            G3.Content = dt.Rows[5][6].ToString();
            G2.Content = dt.Rows[6][6].ToString();
            G1.Content = dt.Rows[7][6].ToString();

            // FILL H COLUMN
            H8.Content = dt.Rows[0][7].ToString();
            H7.Content = dt.Rows[1][7].ToString();
            H6.Content = dt.Rows[2][7].ToString();
            H5.Content = dt.Rows[3][7].ToString();
            H4.Content = dt.Rows[4][7].ToString();
            H3.Content = dt.Rows[5][7].ToString();
            H2.Content = dt.Rows[6][7].ToString();
            H1.Content = dt.Rows[7][7].ToString();
        }
    }
}
